# TKD COACH design system — reference

## 1. Principles
Premium sport technology: black surfaces carry authority, gold marks *what matters* (the action, the active item, the key number), paper keeps data readable. Calm motion (120–350 ms), generous spacing, one icon family, one radius family.

## 2. Colour — 60 / 30 / 10
Brand inputs: **60 % `#F3F6F4` · 30 % `#000000` · 10 % `#DDA110`**.

| Token (semantic) | Light | Dark |
|---|---|---|
| `--bg` (60 %) | `#F3F6F4` | `#111318` |
| `--surface` / `-2` / `-3` | `#FFFFFF` / `#ECF0ED` / `#E1E7E3` | `#1B1E26` / `#252832` / `#303541` |
| `--inverse` (30 %) | `#000000` | `#08090C` |
| `--accent` (10 %) | `#DDA110` | `#DDA110` |
| `--accent-hover` / `-active` | `#E8B93A` / `#B9850B` | same |
| `--accent-text` (gold as text) | `#946809` | `#E8B93A` |
| `--text` / `--text-muted` | `#0B0C0F` / `#59605C` | `#F5F5F3` / `#A0A4AE` |
| `--border` / `--border-strong` | `#DCE3DE` / `#C3CCC6` | `#2B2F3A` / `#3A3F4D` |
| `--disabled-bg` / `-text` | `#E1E7E3` / `#8A938D` | `#252832` / `#6B7180` |
| Success / Danger / Warning / Info (base) | `#16A36A` `#E34D4D` `#F59E0B` `#5798D8` | same |
| `*-ink` (text on tint) | `#0E7A4F` `#B42323` `#8A5200` `#2B6CB0` | `#3DD598` `#FF8A8A` `#FBBF24` `#8CBCEE` |
| `*-soft` (tinted backgrounds) | 12–16 % alpha of the base colour | same |

Palettes: `--gold-50…900`, `--ink-300…950`, `--paper-0…500`. The softer gold of the original brief (`#C5A253`, `#D7B96F`) is kept as `--champagne-500/400` for medals and decorative details.
**Rule:** never put `#DDA110` as small text on light surfaces (2.1–2.3:1) — use `--accent-text`. Use `--text`, not gold, for body text.

### Measured contrast (WCAG)
| Pair | Ratio |
|---|---|
| Text on page, light / dark | 18.0 : 1 / 17.0 : 1 |
| Muted text on page (light) / on surface (dark) | 5.9 : 1 / 6.7 : 1 |
| Black on gold button | 9.2 : 1 |
| Gold numbers on black | 9.2 : 1 |
| `--accent-text` on white / on page (light) | 4.9 : 1 / 4.5 : 1 |
| White on danger button (`#B42323`) / success button (`#0E7A4F`) | 6.6 : 1 / 5.4 : 1 |
| Status ink on white (success, danger, warning, info) | 5.4 / 6.6 / 6.4 / 5.4 : 1 |
| Status ink on dark surface | 7.3 – 9.1 : 1 |

## 3. Themes
`<html data-theme="light|dark">` set by `theme-manager.js`; preference `light | dark | system` in `localStorage["tkd.theme"]`. A 350 ms colour transition is applied only while switching. Components never hard-code colours — they use semantic tokens, so a new theme = one new block in `themes.css`.

## 4. Languages (FR / AR)
`language-manager.js` sets `<html lang dir>`, stores `localStorage["tkd.lang"]`, translates `data-i18n` (text) and `data-i18n-attrs="placeholder:key;aria-label:key"`. Layout uses **logical CSS properties** (`margin-inline`, `inset-inline-start`, `text-align:start`) so RTL needs no separate stylesheet; directional icons use `.icon-flip`; numbers, dates and phone numbers use `.num` to stay LTR; charts keep a left-to-right time axis. Arabic uses Latin digits (`ar-TN-u-nu-latn`) and Tunisian month names (جوان، جويلية، أوت). Typeface switches to Cairo for `:lang(ar)`.

## 5. Tokens
Spacing 4 px base (`--sp-1…12`) · radius 8/12/16/22/pill · type scale 12→48 px · motion `--t-fast/base/slow`, `--ease` · layout `--sidebar-w 272`, `--topbar-h 68`, `--bottomnav-h 68`, `--tap 44` · z-index scale.

## 6. Icons
Lucide-style, 24 px grid, `--icon-stroke: 1.75`, sizes `.icon-sm 16 · .icon 20 · .icon-lg 24`, colour = `currentColor`.
Navigation: layout-dashboard, users, user-round, clipboard-check, chart-no-axes-combined, clipboard-list, calendar-days, settings, bell · Actions: plus, pencil, trash-2, search, sliders-horizontal, save, download, ellipsis, arrow-left, x, check · Performance: trophy, target, zap, dumbbell, history, trending-up, trending-down, calendar-check, timer · UI extras: sun, moon, languages, chevron-right, chevron-down, circle-check, circle-x, triangle-alert, info, log-out, phone, key-round. Brand mark: `logo.svg`.

## 7. Components
| Group | Classes |
|---|---|
| Buttons | `.btn` + `-primary -secondary -success -danger -danger-soft -outline -ghost`, `-icon`, `-sm -lg -block`, `.is-loading`, `[disabled]` |
| Cards | `.card` (`--inverse`, `--hover`), `.stat`, `.athlete`, `.eval`, `.program`, `.session`, `.profile`, `.avatar`, `.activity`, `.quick` |
| Forms | `.field`, `.label`, `.input`, `.select`, `.textarea`, `.input-group`, `.check`, `.switch`, `.segmented`, `.range`/`input[type=range]`, `.hint`, `.error`, `.is-invalid`, `.is-valid`, `.form-grid` |
| Navigation | `.sidebar`, `.nav-item`, `.topbar`, `.lang-switch`, `.icon-btn`, `.crumbs`, `.tabs`/`.tab`, `.bottom-nav`/`.bn` (`.bn--fab`) |
| Data | `.table`, `.table--stack`, `.progress`, `.ring`, `.metric`, `.trend--up/down/flat`, `.badge`, `.belt`, `.chart` + `TKDCharts` |
| Feedback | `.toast` (via `TKD.toast`), `.alert--*`, `.dialog` (native `<dialog>`), `.empty`, `.skeleton`, `.spinner` |

## 8. Layouts
`layouts/desktop/app-shell.html` (sidebar + topbar + bottom nav, fully responsive) · `layouts/mobile/app-shell.html` (compact, no sidebar — athlete/coach mobile use) · pages: dashboard, athletes (table/cards), athlete profile, registration, evaluation, evaluation history, training programs, training sessions, performance analytics, settings, coach interface, athlete interface, components gallery.

## 9. Responsive & safe areas
≥1101 px full sidebar · 861–1100 icon rail · ≤860 px bottom navigation with centre action button · tables stack into labelled rows ≤640 px · `viewport-fit=cover` + `env(safe-area-inset-*)` for iPhone notch/home bar · touch targets ≥ 44 px · `prefers-reduced-motion` respected.

## 10. Accessibility
Skip link, landmark roles, `aria-current`, `aria-selected` tabs with arrow-key navigation (direction-aware in RTL), visible 2 px gold focus ring, native `<dialog>` focus handling, `aria-live` toasts, form errors tied to fields, icon-only buttons carry translated `aria-label`.
