# Installation guide

## 0. Try the demo (no install)
Open `demo/index.html`. Everything is relative, so it works from the unzipped folder.

## 1. Copy the package into the app (nothing existing is overwritten)
Your app serves `public/` with `express.static`. Copy three folders into a **new** sub-folder:
```
tkd-main/public/design-system/
   styles/     scripts/     assets/
```
(Use `styles/tkd-ds.bundle.css` in production — it is the same CSS in one file.)

## 2. Add to a page `<head>` (order matters)
```html
<link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Cairo:wght@400;600;700;800&family=Inter:wght@400;500;600;700;800&display=swap">
<link rel="stylesheet" href="/design-system/styles/tkd-ds.bundle.css">
<script src="/design-system/scripts/theme-manager.js"></script>      <!-- no defer: avoids a theme flash -->
<script src="/design-system/scripts/translations.js"></script>
<script src="/design-system/scripts/language-manager.js"></script>
```
Before `</body>`:
```html
<script src="/design-system/scripts/icons.js"></script>
<script src="/design-system/scripts/charts.js"></script>   <!-- only if the page has charts -->
<script src="/design-system/scripts/ui.js"></script>       <!-- toasts, dialog, tabs, sliders -->
```
No server change is needed: all scripts are external (compatible with the existing Helmet CSP `script-src 'self'`).

## 3. Use the components
* Copy markup from `components/**` (each file lists what it needs).
* Icons: `<i class="icon" data-icon="trophy"></i>` — after injecting HTML dynamically call `TKDIcons.hydrate(container)`.
* Text: `<span data-i18n="nav.dashboard"></span>`; in JS: `TKDI18n.t('toast.saved.title')`. Add new keys to **both** languages in `translations.js`.
* Theme / language switchers: `<button data-theme-toggle>`, `<button data-lang-set="fr|ar">`, `<input type="radio" name="theme-pref" value="light|dark|system">`.
* Toast: `TKD.toast({type:'success', title:'…', text:'…'})` · Dialog: `<dialog class="dialog">` + `TKD.openDialog(id)`.
* Charts: `TKDCharts.mount('#el','line',{labels:[…], series:[{name:'Score', data:[…]}]})` — types `line | bars | radar | donut`.

## 4. Adding a language key or icon, then rebuilding
```
python3 tools/build.py     # regenerates icons.js, bundle css, demo, components
python3 tools/check.py     # validates translations, icons, css variables, html
```
Add an icon: drop a Lucide `name.svg` into `assets/icons/` and rebuild.
