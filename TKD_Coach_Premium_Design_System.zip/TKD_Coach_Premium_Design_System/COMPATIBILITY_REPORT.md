# Compatibility report — TKD COACH application

Analysed from the uploaded project (`tkd-main-approval-gate`).

## Detected architecture
| Item | Finding |
|---|---|
| Frontend | **Plain HTML + vanilla JavaScript** in `public/` (`coach.html`, `athlete.html`, `index.html`; UI rendered as HTML strings by `coach.js`, `athlete.js`, `register.js`) — no React, no Tailwind, no bundler |
| CSS | A single `public/app.css` (~60 classes) |
| Icons | Emojis in markup — no icon library |
| Routing | Express static pages (`/`, `/coach`, `/athlete`); in-page tab switching in `coach.js` (no client router) |
| Backend | Node + Express + **MongoDB (Mongoose)**, Helmet default CSP, `express.static('public')` |
| Note | The brief mentions **Supabase**; the uploaded code does not use it (it uses MongoDB). Nothing related to either database is touched. |

→ The design system is therefore plain CSS + vanilla JS: no new framework is introduced.

## Files that must remain untouched
`server.js` (routes, auth, Mongoose models, API) · `package.json` / `.env` · `criteria.js`, `age-category.js`, `notes.js`, `eval-view.js` (scoring and business logic) · API calls inside `coach.js` / `athlete.js` / `register.js` (`fetch`, payloads, validation) · all tests under `test/`.

## Files to modify when you integrate (presentation only)
| File | Change |
|---|---|
| `public/coach.html`, `athlete.html`, `index.html` | Add the `<link>`/`<script>` tags from `INSTALLATION_GUIDE.md` |
| `public/coach.js`, `athlete.js`, `register.js` | Only the **HTML-string markup / class names** inside the render functions (not logic, ids or handlers) |
| `public/app.css` | Retire it page by page once a page is migrated |
| `public/manifest.webmanifest`, `icon-*.png` | Optional: `theme_color` `#000000` and the new logo (`assets/icons/logo.svg`) |
| `test-helpers/dom.js` | Only if migrated code calls `TKDIcons`/`TKDI18n` in tests: load `icons.js` there |

## ⚠ Known conflict: duplicate class names
These classes exist **both** in the current `app.css` and in the design system, with different styling:

`bar · btn · card · field · item · link · metric · muted · row2 · seg · tab · tag · tile · toast · total`

**Do not load both stylesheets on the same page.** Safe integration paths:
1. **Preview only (zero risk):** serve the package under `/design-system/` and open `demo/index.html` — the app is unaffected.
2. **Page by page (recommended):** migrate one page (e.g. `athlete.html`), switch its markup to the design-system classes, drop `app.css` from that page only.
3. Keep the existing ids (`#e_p`, `#saveEval`, …) and `data-*` hooks while changing classes, so the JavaScript behaviour and the existing tests keep working.

Suggested mapping: `.btn`→`.btn .btn-primary` · `.seg`→`.segmented` · `.item`→`.card` · `.tag`→`.badge` · `.tile`→`.card .card--hover` · `.total`→`.card .card--inverse` · `.metric`→`.range` · `.toast`→`TKD.toast()`.

## Security / platform compatibility
* Helmet CSP: no inline scripts or `eval`; styles/fonts over `https:` and `data:` SVG backgrounds are allowed by the default policy.
* Data stored by the package: only `localStorage` keys `tkd.theme` and `tkd.lang` (no personal data).
* No impact on authentication, API calls, athlete or evaluation records, registration workflow.
