#!/usr/bin/env python3
"""Quality checks:  python3 tools/check.py
 • every data-i18n / data-i18n-attrs / '@key' / t('key') key exists in BOTH languages (and no unused keys)
 • every <i data-icon> and every icon file used exists; icon SVGs are well-formed
 • every CSS var(--x) used is defined; CSS braces balance
 • HTML tag balance for demo/index.html
"""
import re, os, sys, json, glob, subprocess
from html.parser import HTMLParser
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__))); P = lambda *a: os.path.join(ROOT, *a)
rd = lambda p: open(p, encoding='utf8').read()
bad = 0
def fail(m):
    global bad; bad += 1; print('  ✗', m)
def ok(m): print('  ✓', m)

# ---- i18n ----
tr = json.loads(subprocess.check_output(['node', '-e', "global.window={};require('%s');process.stdout.write(JSON.stringify(window.TKD_TRANSLATIONS))" % P('scripts/translations.js')]))
used = set()
for f in glob.glob(P('layouts/**/*.html'), recursive=True) + [P('demo/index.html')] + glob.glob(P('components/**/*.html'), recursive=True):
    h = rd(f)
    used |= set(re.findall(r'data-i18n="([^"]+)"', h))
    for a in re.findall(r'data-i18n-attrs="([^"]+)"', h):
        used |= {p.split(':', 1)[1].strip() for p in a.split(';') if ':' in p}
js = rd(P('scripts/ui.js')) + rd(P('demo/demo.js')) + rd(P('scripts/charts.js'))
used |= set(re.findall(r"'@([\w.]+)'", js)); used |= set(re.findall(r"\bt\('([\w.]*\w)'", js))
for ty in ('success', 'danger', 'warning', 'info'): used |= {f'toast.{ty}.title', f'toast.{ty}.text'}
for n in re.findall(r'data-view="(\w+)"', rd(P('demo/index.html'))): used.add(f'page.{n}.title')
used = {k for k in used if k}
print('i18n'); 
for lang in ('fr', 'ar'):
    miss = sorted(k for k in used if k not in tr.get(lang, {}))
    (fail(f'{lang}: {len(miss)} missing: {miss[:60]}') if miss else ok(f'{lang}: all {len(used)} used keys present'))
fa = set(tr['fr']) ^ set(tr['ar']); (fail(f'fr/ar key mismatch: {sorted(fa)[:20]}') if fa else ok(f'fr and ar have identical key sets ({len(tr["fr"])})'))
dyn = re.compile(r'^(page\.\w+\.(title|sub)|toast\..*)$')
unused = sorted(k for k in tr['fr'] if k not in used and not dyn.match(k)); (print('  ! unused keys (' + str(len(unused)) + '):', unused[:30]) if unused else ok('no unused keys'))
for k in tr['fr']:
    if '{' in tr['fr'][k] and set(re.findall(r'\{\w+\}', tr['fr'][k])) != set(re.findall(r'\{\w+\}', tr['ar'][k])): fail('placeholder mismatch ' + k)

# ---- icons ----
print('icons'); names = {os.path.basename(f)[:-4] for f in glob.glob(P('assets/icons/*.svg'))}
need = set(re.findall(r'data-icon="([\w-]+)"', rd(P('demo/index.html')))) | set(re.findall(r'data-icon="([\w-]+)"', js)) | set(ICON for ICON in re.findall(r"(?:success|danger|warning|info): '([\w-]+)'", js))
miss = sorted(need - names); (fail('missing icons: %s' % miss) if miss else ok(f'{len(need)} icons used, all exist'))
spec = ['layout-dashboard','users','user-round','clipboard-check','chart-no-axes-combined','clipboard-list','calendar-days','settings','bell','plus','pencil','trash-2','search','sliders-horizontal','save','download','ellipsis','arrow-left','x','check','trophy','target','zap','dumbbell','history','trending-up','trending-down','calendar-check','timer']
miss = [n for n in spec if n not in names]; (fail('brief icons missing: %s' % miss) if miss else ok('all 29 icons requested in the brief are present'))
for f in glob.glob(P('assets/icons/*.svg')):
    h = P and rd(f)
    p = HTMLParser(); 
    if h.count('<svg') != 1 or '</svg>' not in h: fail('malformed ' + f)
# ---- css ----
print('css'); css = ''.join(rd(f) for f in glob.glob(P('styles/*.css')) if not f.endswith('bundle.css'))
defined = set(re.findall(r'(--[\w-]+)\s*:', css)); usedv = set(re.findall(r'var\((--[\w-]+)', css))
inline = set(re.findall(r'var\((--[\w-]+)', rd(P('demo/index.html'))))
undefined = sorted((usedv | inline) - defined - {'--v', '--p', '--s', '--c', '--ci', '--in', '--b-bg', '--b-fg', '--b-bd', '--belt'})
(fail(f'undefined css vars: {undefined}') if undefined else ok(f'{len(usedv)} css variables used, all defined'))
for f in glob.glob(P('styles/*.css')):
    t = rd(f); (fail(f'brace mismatch in {f}') if t.count('{') != t.count('}') else None)
ok('css braces balanced')
# ---- html balance ----
print('html')
class B(HTMLParser):
    VOID = {'meta', 'link', 'input', 'br', 'img', 'hr', 'use', 'source'}
    def __init__(s): super().__init__(); s.st = []; s.e = []
    def handle_starttag(s, t, a):
        if t not in s.VOID: s.st.append(t)
    def handle_startendtag(s, t, a): pass
    def handle_endtag(s, t):
        if t in s.VOID: return
        if s.st and s.st[-1] == t: s.st.pop()
        else: s.e.append((t, s.st[-2:]))
b = B(); b.feed(rd(P('demo/index.html'))); (fail(f'html balance: {b.e[:3]} open={b.st[:3]}') if b.e or b.st else ok('demo/index.html tags balanced'))
ids = re.findall(r'\bid="([^"]+)"', rd(P('demo/index.html'))); dup = sorted({i for i in ids if ids.count(i) > 1}); (fail(f'duplicate ids: {dup}') if dup else ok('no duplicate ids'))
sys.exit(1 if bad else 0)
