# TKD COACH — Premium Design System

Black-and-gold sport-technology design system for the TKD COACH app. Plain HTML / CSS / JavaScript (same stack as the existing app — **no framework, no build step needed to use it**). Light + dark themes, French (LTR) + Arabic (RTL), responsive from iPhone to desktop.

> **See it first:** open `demo/index.html` in any modern browser (double-click, no server required). Use the **FR / عربي** switch and the sun/moon button in the top bar.

## Colour rule — 60 / 30 / 10
| Share | Colour | Where it is used |
|---|---|---|
| **60 %** | Paper `#F3F6F4` | Page background and white surfaces (dark theme: `#111318` / `#1B1E26`) |
| **30 %** | Black `#000000` | Sidebar, bottom navigation, feature cards, score badges, secondary buttons |
| **10 %** | Gold `#DDA110` | Primary buttons, active indicators, key numbers, slider/progress fills, focus rings |

Gold is never used as small text on light backgrounds (contrast 2.1–2.3:1); text uses the darker `--accent-text` (`#946809`, 4.9:1).

## What is inside
```
README.md · INSTALLATION_GUIDE.md · DESIGN_SYSTEM.md · COMPATIBILITY_REPORT.md
assets/icons/        41 Lucide-style SVGs (one file each) + sprite.svg + logo.svg
assets/fonts/        README only — fonts are NOT bundled (see file)
styles/              variables · themes · typography · layout · buttons · cards · forms · badges · tables ·
                     navigation · feedback · charts · responsive · main.css · tkd-ds.bundle.css (production)
scripts/             theme-manager · language-manager · translations (FR+AR, 314 keys) · icons · charts · ui
components/          copy-paste HTML per component (buttons, cards, forms, navigation, feedback, data-viz, badges, tables)
layouts/             desktop/app-shell · mobile/app-shell · dashboard/dashboard · pages/* (11 pages)
demo/                index.html (interactive demo) · demo.js (sample chart data) · screenshots/
tools/               build.py (regenerates icons.js, bundle, demo, components) · check.py (quality checks)
```

### File purposes
| File | Purpose |
|---|---|
| `styles/variables.css` | Raw tokens: gold/ink/paper scales, spacing, radius, type scale, motion, layout sizes |
| `styles/themes.css` | Semantic tokens for **light** and **dark** (`<html data-theme>`); components only use these |
| `styles/typography.css` | Font stacks (Inter / Cairo), headings, utilities (`.num` keeps numbers LTR inside Arabic) |
| `styles/layout.css` | App shell grid, page header, grid/stack/row utilities, `.icon` sizing |
| `styles/buttons.css` | Primary, secondary, success, danger, outline, ghost, icon, loading, disabled, sizes |
| `styles/cards.css` | Stat, athlete, evaluation, program, session, profile cards, avatar, activity list |
| `styles/forms.css` | Inputs, search, select, date, textarea, checkbox, radio, switch, segmented, slider, validation |
| `styles/badges.css` | Status badges, belt chips, improvement/decline indicators |
| `styles/tables.css` | Data table, toolbar, sticky header, stacked mobile layout |
| `styles/navigation.css` | Sidebar, topbar, language/theme switchers, breadcrumbs, tabs, mobile bottom navigation |
| `styles/feedback.css` | Toasts, alerts, confirmation `<dialog>`, empty state, skeleton, spinner |
| `styles/charts.css` | Progress bars, score ring, metrics, SVG-chart styling, legends |
| `styles/responsive.css` | Breakpoints (≥1101 sidebar · 861–1100 icon rail · ≤860 bottom nav), safe areas, print |
| `scripts/theme-manager.js` | Light / dark / system, saved in `localStorage`, smooth transition, no flash |
| `scripts/language-manager.js` | FR/AR switching, `dir`/`lang` update, `data-i18n`, number/date formatting |
| `scripts/translations.js` | Complete French + Arabic dictionaries |
| `scripts/icons.js` | Generated icon sprite + `<i data-icon="…">` hydration |
| `scripts/charts.js` | Line, bar, radar and donut charts (SVG, theme + language aware) |
| `scripts/ui.js` | Toasts, dialog, tabs, sliders, validation, demo router (use only what you need) |

## Quality control performed
* **Headless Chromium (Playwright)**: 13 pages × light/dark × FR/AR × 3 viewports (1366, 820, 390 px) — **0 failures**: no horizontal overflow, all icons render, no untranslated keys, no console errors; theme and language persist after reload; tabs, dialog, toast, slider total, table filter, form validation, view toggle all verified.
* `tools/check.py`: FR and AR have identical key sets and cover every key used; all 29 icons requested in the brief exist; every CSS variable used is defined; HTML tags balanced; no duplicate ids.
* WCAG contrast measured (see `DESIGN_SYSTEM.md`); two failing button colours were found and fixed.

## Honest limitations
* **Icons**: Lucide's npm package could not be downloaded here, so the 41 icons were authored from Lucide's published geometry (same names, 24 px grid, 2 px stroke). To use the byte-exact official files, copy them from `lucide-static` into `assets/icons/` and run `python3 tools/build.py`.
* **Fonts** are loaded from Google Fonts (or fall back to system fonts) — see `assets/fonts/README.md`.
* Tested in Chromium only. Safari/iOS and Firefox were not available; the CSS uses standard features (`<dialog>`, `color-mix()`, logical properties) supported by current Safari, Chrome, Edge and Firefox.
* The demo data (names, scores) is fictional.
