/* TKD COACH — UI behaviours for the design system (router for the demo, tabs, toasts, dialogs, sliders, validation).
   Everything is progressive: components work with plain markup; this file only wires the interactions.
   In the real app you will normally keep only the parts you need (toasts, dialog, tabs, sliders). */
(function (root) {
  'use strict';
  var doc = document, $ = function (s, c) { return (c || doc).querySelector(s); }, $$ = function (s, c) { return Array.prototype.slice.call((c || doc).querySelectorAll(s)); };
  var t = function (k, p) { return root.TKDI18n ? root.TKDI18n.t(k, p) : k; };
  var ICON = { success: 'circle-check', danger: 'circle-x', warning: 'triangle-alert', info: 'info' };

  /* ---------- toasts ---------- */
  function toast(o) {
    var box = $('.toasts'); if (!box) { box = doc.createElement('div'); box.className = 'toasts'; box.setAttribute('role', 'status'); box.setAttribute('aria-live', 'polite'); doc.body.appendChild(box); }
    var el = doc.createElement('div'); el.className = 'toast toast--' + (o.type || 'info');
    el.innerHTML = '<i class="icon" data-icon="' + ICON[o.type || 'info'] + '"></i><div class="toast__body"><b></b><span></span></div><button type="button" aria-label="' + t('common.close') + '"><i class="icon icon-sm" data-icon="x"></i></button>';
    el.querySelector('b').textContent = o.title || ''; el.querySelector('span').textContent = o.text || '';
    box.appendChild(el); root.TKDIcons && root.TKDIcons.hydrate(el);
    var close = function () { el.classList.add('is-out'); setTimeout(function () { el.remove(); }, 220); };
    el.querySelector('button').addEventListener('click', close); setTimeout(close, o.duration || 4200);
    return el;
  }
  /* ---------- dialog ---------- */
  function openDialog(id) { var d = doc.getElementById(id); if (d && d.showModal) { d.showModal(); } }
  doc.addEventListener('click', function (e) {
    var tt = e.target.closest('[data-toast]'); if (tt) { var ty = tt.getAttribute('data-toast'); toast({ type: ty, title: t('toast.' + ty + '.title'), text: t('toast.' + ty + '.text') }); }
    var od = e.target.closest('[data-dialog-open]'); if (od) openDialog(od.getAttribute('data-dialog-open'));
    var cd = e.target.closest('[data-dialog-close]'); if (cd) { var d = cd.closest('dialog'); d && d.close(cd.getAttribute('data-dialog-close') || ''); }
    var ld = e.target.closest('[data-loading-demo]'); if (ld) { ld.classList.add('is-loading'); setTimeout(function () { ld.classList.remove('is-loading'); }, 1600); }
    if (e.target.matches('dialog.dialog')) e.target.close('backdrop');
    var ac = e.target.closest('[data-action]'); if (ac) { var a = ac.getAttribute('data-action'); if (a === 'accept') { toast({ type: 'success', title: t('toast.accepted.title'), text: t('toast.accepted.text') }); var it = ac.closest('.pending'); if (it) it.remove(); } if (a === 'save') toast({ type: 'success', title: t('toast.saved.title'), text: t('toast.saved.text') }); if (a === 'delete') openDialog('dlg-delete'); }
  });
  $$('dialog.dialog').forEach(function (d) { d.addEventListener('close', function () { if (d.returnValue === 'confirm') toast({ type: 'danger', title: t('toast.deleted.title'), text: t('toast.deleted.text') }); d.returnValue = ''; }); });

  /* ---------- tabs ---------- */
  $$('[role="tablist"]').forEach(function (list) {
    var tabs = $$('[role="tab"]', list), sel = function (tab) {
      tabs.forEach(function (x) { var on = x === tab; x.setAttribute('aria-selected', on); x.tabIndex = on ? 0 : -1; var p = doc.getElementById(x.getAttribute('aria-controls')); if (p) p.hidden = !on; });
    };
    tabs.forEach(function (tab, i) {
      tab.addEventListener('click', function () { sel(tab); });
      tab.addEventListener('keydown', function (e) {
        var rtl = doc.documentElement.dir === 'rtl', n = { ArrowRight: rtl ? -1 : 1, ArrowLeft: rtl ? 1 : -1 }[e.key]; if (!n) return;
        var nx = tabs[(i + n + tabs.length) % tabs.length]; nx.focus(); sel(nx); e.preventDefault();
      });
    });
  });
  /* ---------- segmented view toggle (table / cards) ---------- */
  doc.addEventListener('change', function (e) {
    var r = e.target; if (!r.matches('[data-view-toggle]')) return;
    $$('[data-pane]').forEach(function (p) { if (p.getAttribute('data-group') === r.getAttribute('data-view-toggle')) p.hidden = p.getAttribute('data-pane') !== r.value; });
  });
  /* ---------- sliders + live evaluation total ---------- */
  function paint(r) { var p = (r.value - r.min) / (r.max - r.min) * 100; r.style.setProperty('--p', p + '%'); var o = r.closest('.range') && $('output', r.closest('.range')); if (o) o.textContent = r.value + '/' + r.max; }
  function total() {
    var box = $('[data-eval-total]'); if (!box) return; var s = 0, m = 0;
    $$('.view[data-view="evaluation"] input[type=range]').forEach(function (r) { s += +r.value; m += +r.max; });
    $('[data-eval-sum]').textContent = s; $('[data-eval-max]').textContent = '/' + m; var pc = Math.round(s / m * 100);
    $('[data-eval-pct]').textContent = pc + '%'; $('[data-eval-bar]').style.setProperty('--v', pc); box.querySelector('.ring').style.setProperty('--v', pc);
  }
  doc.addEventListener('input', function (e) { if (e.target.matches('input[type=range]')) { paint(e.target); total(); } });
  $$('input[type=range]').forEach(paint); total();
  /* ---------- table filter ---------- */
  doc.addEventListener('input', function (e) {
    var f = e.target.closest('[data-filter]'); if (!f) return; var q = f.value.trim().toLowerCase();
    $$(f.getAttribute('data-filter') + ' tbody tr').forEach(function (tr) { tr.hidden = q && tr.textContent.toLowerCase().indexOf(q) < 0; });
  });
  /* ---------- form validation (registration demo) ---------- */
  var form = $('#form-register');
  if (form) form.addEventListener('submit', function (e) {
    e.preventDefault(); var ok = true;
    $$('.field[data-validate]', form).forEach(function (f) {
      var i = $('input,select', f), v = (i.value || '').trim(), rule = f.getAttribute('data-validate'), bad = !v || (rule === 'phone' && !/^[0-9 +]{8,15}$/.test(v));
      f.classList.toggle('is-invalid', bad); f.classList.toggle('is-valid', !bad); if (bad) ok = false;
    });
    if (ok) toast({ type: 'success', title: t('toast.saved.title'), text: t('toast.saved.text') }); else toast({ type: 'warning', title: t('toast.invalid.title'), text: t('toast.invalid.text') });
  });
  /* ---------- router (demo): #/dashboard, #/athletes … ---------- */
  var current = 'dashboard';
  function go(name) {
    var v = $('.view[data-view="' + name + '"]'); if (!v) name = 'dashboard', v = $('.view[data-view="dashboard"]');
    current = name; $$('.view').forEach(function (x) { x.classList.toggle('is-active', x === v); });
    var group = v.getAttribute('data-nav') || name;
    $$('[data-nav-link]').forEach(function (a) { var on = a.getAttribute('data-nav-link') === group; a.classList.toggle('is-active', on); on ? a.setAttribute('aria-current', 'page') : a.removeAttribute('aria-current'); });
    var c = $('[data-crumb]'); if (c) c.setAttribute('data-i18n', 'page.' + name + '.title');
    root.TKDI18n && (root.TKDI18n.apply(), doc.title = t('page.' + name + '.title') + ' · TKD COACH');
    root.scrollTo(0, 0);
  }
  function route() { go((root.location.hash.replace(/^#\/?/, '') || 'dashboard').split('?')[0]); }
  root.addEventListener('hashchange', route);
  root.addEventListener('tkd:languagechange', function () { doc.title = t('page.' + current + '.title') + ' · TKD COACH'; });
  /* ---------- boot ---------- */
  function boot() {
    var gal = $('[data-icon-gallery]');
    if (gal && root.TKDIcons) gal.innerHTML = root.TKDIcons.names().map(function (n) { return '<div class="icon-tile"><i class="icon" data-icon="' + n + '"></i><span>' + n + '</span></div>'; }).join('');
    root.TKDIcons && root.TKDIcons.hydrate();
    if (root.TKDCharts && root.TKD_DEMO) root.TKD_DEMO.charts();
    if ($('.view')) route();
  }
  if (doc.readyState === 'loading') doc.addEventListener('DOMContentLoaded', boot); else boot();
  root.TKD = { toast: toast, openDialog: openDialog, go: go };
})(window);
