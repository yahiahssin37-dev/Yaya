/* TKD COACH — theme manager. Load in <head> (no defer) so the theme is applied before first paint.
   Preference: 'light' | 'dark' | 'system' — persisted in localStorage ("tkd.theme"). Sets <html data-theme="light|dark">. */
(function (root) {
  'use strict';
  var KEY = 'tkd.theme', doc = document, html = doc.documentElement;
  var mq = root.matchMedia ? root.matchMedia('(prefers-color-scheme: dark)') : null;
  var COLORS = { light: '#F3F6F4', dark: '#111318' };

  function pref() { try { return root.localStorage.getItem(KEY) || 'system'; } catch (e) { return 'system'; } }
  function resolve(p) { return p === 'system' ? (mq && mq.matches ? 'dark' : 'light') : p; }

  function apply(p, animate) {
    var t = resolve(p);
    if (animate) { html.classList.add('theme-transition'); root.setTimeout(function () { html.classList.remove('theme-transition'); }, 450); }
    html.setAttribute('data-theme', t);
    html.setAttribute('data-theme-pref', p);
    var m = doc.querySelector('meta[name="theme-color"]');
    if (!m) { m = doc.createElement('meta'); m.name = 'theme-color'; doc.head.appendChild(m); }
    m.content = COLORS[t];
    syncControls();
    root.dispatchEvent(new CustomEvent('tkd:themechange', { detail: { preference: p, theme: t } }));
  }
  function set(p) {
    if (['light', 'dark', 'system'].indexOf(p) < 0) return;
    try { root.localStorage.setItem(KEY, p); } catch (e) { /* private mode: theme still applies for this session */ }
    apply(p, true);
  }
  function toggle() { set(resolve(pref()) === 'dark' ? 'light' : 'dark'); }

  function syncControls() {
    var p = pref();
    Array.prototype.forEach.call(doc.querySelectorAll('input[name="theme-pref"]'), function (i) { i.checked = i.value === p; });
  }
  function bind() {
    doc.addEventListener('click', function (e) { if (e.target.closest('[data-theme-toggle]')) toggle(); });
    doc.addEventListener('change', function (e) { if (e.target.name === 'theme-pref') set(e.target.value); });
    syncControls();
  }
  if (mq && mq.addEventListener) mq.addEventListener('change', function () { if (pref() === 'system') apply('system', true); });

  apply(pref(), false);
  if (doc.readyState === 'loading') doc.addEventListener('DOMContentLoaded', bind); else bind();
  root.TKDTheme = { get: pref, set: set, toggle: toggle, resolved: function () { return html.getAttribute('data-theme'); } };
})(window);
