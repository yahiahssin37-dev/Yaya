/* TKD COACH — language manager (French / Arabic).
   - Text:        <span data-i18n="nav.dashboard"></span>
   - Attributes:  <input data-i18n-attrs="placeholder:form.search;aria-label:form.search">
   - In JS:       TKDI18n.t('toast.saved', {name:'Slim'})   ·   TKDI18n.number(1234.5)   ·   TKDI18n.date(new Date())
   Sets <html lang dir>; persisted in localStorage ("tkd.lang"). Requires translations.js (window.TKD_TRANSLATIONS). */
(function (root) {
  'use strict';
  var KEY = 'tkd.lang', DEFAULT = 'fr', doc = document, html = doc.documentElement;
  var LANGS = { fr: { dir: 'ltr', locale: 'fr-FR' }, ar: { dir: 'rtl', locale: 'ar-TN-u-nu-latn' } };   // Arabic with Latin digits (usual in Tunisia)
  var current = DEFAULT, listeners = [];

  function table(l) { return (root.TKD_TRANSLATIONS || {})[l] || {}; }
  function t(key, params) {
    var s = table(current)[key];
    if (s == null) { s = table(DEFAULT)[key]; if (s == null) { if (root.TKD_DEBUG) console.warn('[i18n] missing key:', key); s = key; } }
    return params ? s.replace(/\{(\w+)\}/g, function (m, k) { return params[k] != null ? params[k] : m; }) : s;
  }
  function apply(scope) {
    scope = scope || doc;
    Array.prototype.forEach.call(scope.querySelectorAll('[data-i18n]'), function (el) { el.textContent = t(el.getAttribute('data-i18n')); });
    Array.prototype.forEach.call(scope.querySelectorAll('[data-i18n-attrs]'), function (el) {
      el.getAttribute('data-i18n-attrs').split(';').forEach(function (pair) {
        var i = pair.indexOf(':'); if (i > 0) el.setAttribute(pair.slice(0, i).trim(), t(pair.slice(i + 1).trim()));
      });
    });
  }
  function stored() { try { return root.localStorage.getItem(KEY); } catch (e) { return null; } }
  function set(l, silent) {
    if (!LANGS[l]) return;
    current = l;
    html.setAttribute('lang', l); html.setAttribute('dir', LANGS[l].dir);
    if (!silent) { try { root.localStorage.setItem(KEY, l); } catch (e) { /* ignore */ } }
    apply();
    Array.prototype.forEach.call(doc.querySelectorAll('[data-lang-set]'), function (b) { b.setAttribute('aria-pressed', String(b.getAttribute('data-lang-set') === l)); });
    listeners.forEach(function (fn) { fn(l); });
    root.dispatchEvent(new CustomEvent('tkd:languagechange', { detail: { lang: l, dir: LANGS[l].dir } }));
  }
  function number(n, o) { return new Intl.NumberFormat(LANGS[current].locale, o).format(n); }
  function date(d, o) { return new Intl.DateTimeFormat(LANGS[current].locale, o || { day: '2-digit', month: 'short', year: 'numeric' }).format(d); }

  // Set lang/dir immediately (script in <head>) to avoid a layout flash; translate once the DOM is ready.
  var first = stored() || ((navigator.language || '').toLowerCase().indexOf('ar') === 0 ? 'ar' : DEFAULT);
  if (!LANGS[first]) first = DEFAULT;
  current = first; html.setAttribute('lang', first); html.setAttribute('dir', LANGS[first].dir);
  function init() {
    doc.addEventListener('click', function (e) { var b = e.target.closest('[data-lang-set]'); if (b) set(b.getAttribute('data-lang-set')); });
    set(first, true);
  }
  if (doc.readyState === 'loading') doc.addEventListener('DOMContentLoaded', init); else init();
  root.TKDI18n = { t: t, set: set, get: function () { return current; }, dir: function () { return LANGS[current].dir; }, apply: apply, number: number, date: date, onChange: function (fn) { listeners.push(fn); } };
})(window);
