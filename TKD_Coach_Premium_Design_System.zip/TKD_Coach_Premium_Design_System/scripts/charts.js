/* TKD COACH — dependency-free SVG charts that follow the theme through CSS variables (--chart-1 … --chart-5).
   TKDCharts.mount('#el', 'line'|'bars'|'radar'|'donut', spec)  — re-renders automatically on language change.
   Labels starting with "@" are i18n keys (e.g. "@cat.speed"). */
(function (root) {
  'use strict';
  var NS = 'http://www.w3.org/2000/svg', uid = 0, mounted = [];
  var C = ['var(--chart-1)', 'var(--chart-2)', 'var(--chart-3)', 'var(--chart-4)', 'var(--chart-5)'];
  function tr(s) { return typeof s === 'string' && s.charAt(0) === '@' && root.TKDI18n ? root.TKDI18n.t(s.slice(1)) : s; }
  function num(n) { return root.TKDI18n ? root.TKDI18n.number(n) : String(n); }
  function esc(s) { return String(s).replace(/[&<>"]/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]; }); }
  function col(s, i) { return s.color || C[i % C.length]; }
  function legend(series) { return '<div class="legend" style="margin-block-start:12px">' + series.map(function (s, i) { return '<span><i style="--c:' + col(s, i) + '"></i>' + esc(tr(s.name)) + '</span>'; }).join('') + '</div>'; }
  function wrap(label, w, h, inner, series) { return '<svg viewBox="0 0 ' + w + ' ' + h + '" role="img" aria-label="' + esc(label) + '"><title>' + esc(label) + '</title>' + inner + '</svg>' + (series ? legend(series) : ''); }

  function smooth(p) {                       // Catmull-Rom → cubic Bézier
    var d = 'M' + p[0][0] + ',' + p[0][1];
    for (var i = 0; i < p.length - 1; i++) {
      var a = p[i - 1] || p[i], b = p[i], c = p[i + 1], e = p[i + 2] || c;
      d += ' C' + (b[0] + (c[0] - a[0]) / 6) + ',' + (b[1] + (c[1] - a[1]) / 6) + ' ' + (c[0] - (e[0] - b[0]) / 6) + ',' + (c[1] - (e[1] - b[1]) / 6) + ' ' + c[0] + ',' + c[1];
    }
    return d;
  }
  function line(spec) {
    var W = 640, H = spec.height || 260, L = 40, R = 14, T = 14, B = 30, id = 'g' + (++uid);
    var all = [].concat.apply([], spec.series.map(function (s) { return s.data; }));
    var min = spec.min != null ? spec.min : Math.floor(Math.min.apply(null, all) / 10) * 10, max = spec.max != null ? spec.max : Math.ceil(Math.max.apply(null, all) / 10) * 10;
    var n = spec.labels.length, x = function (i) { return L + (W - L - R) * (n < 2 ? .5 : i / (n - 1)); }, y = function (v) { return T + (H - T - B) * (1 - (v - min) / (max - min || 1)); };
    var s = '<defs>' + spec.series.map(function (se, i) { return '<linearGradient id="' + id + i + '" x1="0" x2="0" y1="0" y2="1"><stop offset="0" stop-color="' + col(se, i) + '" stop-opacity=".28"/><stop offset="1" stop-color="' + col(se, i) + '" stop-opacity="0"/></linearGradient>'; }).join('') + '</defs>';
    for (var g = 0; g <= 4; g++) { var v = min + (max - min) * g / 4, yy = y(v); s += '<line class="grid-line" x1="' + L + '" x2="' + (W - R) + '" y1="' + yy + '" y2="' + yy + '"/><text x="' + (L - 8) + '" y="' + (yy + 4) + '" text-anchor="end">' + num(Math.round(v)) + '</text>'; }
    spec.labels.forEach(function (l, i) { s += '<text x="' + x(i) + '" y="' + (H - 8) + '" text-anchor="middle">' + esc(tr(l)) + '</text>'; });
    spec.series.forEach(function (se, i) {
      var p = se.data.map(function (v, k) { return [+x(k).toFixed(1), +y(v).toFixed(1)]; }), d = smooth(p);
      if (i === 0 && spec.area !== false) s += '<path d="' + d + ' L' + p[p.length - 1][0] + ',' + (H - B) + ' L' + p[0][0] + ',' + (H - B) + ' Z" fill="url(#' + id + i + ')"/>';
      s += '<path class="line" d="' + d + '" stroke="' + col(se, i) + '"/>';
      p.forEach(function (pt, k) { if (k === p.length - 1 || spec.points) s += '<circle class="pt" cx="' + pt[0] + '" cy="' + pt[1] + '" r="4.5" fill="' + col(se, i) + '"><title>' + esc(tr(se.name)) + ': ' + num(se.data[k]) + '</title></circle>'; });
    });
    return wrap(spec.title || 'chart', W, H, s, spec.series.length > 1 ? spec.series : null);
  }
  function bars(spec) {
    var W = 640, H = spec.height || 260, L = 40, R = 14, T = 14, B = 30, max = spec.max || Math.ceil(Math.max.apply(null, [].concat.apply([], spec.series.map(function (s) { return s.data; }))) / 10) * 10;
    var n = spec.labels.length, gw = (W - L - R) / n, bw = Math.min(26, gw / (spec.series.length + 1)), y = function (v) { return T + (H - T - B) * (1 - v / max); }, s = '';
    for (var g = 0; g <= 4; g++) { var yy = y(max * g / 4); s += '<line class="grid-line" x1="' + L + '" x2="' + (W - R) + '" y1="' + yy + '" y2="' + yy + '"/><text x="' + (L - 8) + '" y="' + (yy + 4) + '" text-anchor="end">' + num(Math.round(max * g / 4)) + '</text>'; }
    spec.labels.forEach(function (l, i) {
      var cx = L + gw * i + gw / 2; s += '<text x="' + cx + '" y="' + (H - 8) + '" text-anchor="middle">' + esc(tr(l)) + '</text>';
      spec.series.forEach(function (se, k) { var h = (H - B) - y(se.data[i]), bx = cx - (bw * spec.series.length + 4 * (spec.series.length - 1)) / 2 + k * (bw + 4); s += '<rect class="bar" x="' + bx + '" y="' + y(se.data[i]) + '" width="' + bw + '" height="' + h + '" rx="5" fill="' + col(se, k) + '"><title>' + esc(tr(se.name)) + ': ' + num(se.data[i]) + '</title></rect>'; });
    });
    return wrap(spec.title || 'chart', W, H, s, spec.series.length > 1 ? spec.series : null);
  }
  function radar(spec) {
    var S = 320, c = S / 2, r = 104, n = spec.labels.length, max = spec.max || 100, s = '';
    var pt = function (i, v) { var a = -Math.PI / 2 + 2 * Math.PI * i / n; return [c + Math.cos(a) * r * v / max, c + Math.sin(a) * r * v / max]; };
    [.25, .5, .75, 1].forEach(function (k) { s += '<polygon class="radar-web" points="' + spec.labels.map(function (_, i) { return pt(i, max * k).map(function (v) { return v.toFixed(1); }).join(','); }).join(' ') + '"/>'; });
    spec.labels.forEach(function (l, i) { var e = pt(i, max), a = pt(i, max * 1.2); s += '<line class="radar-web" x1="' + c + '" y1="' + c + '" x2="' + e[0] + '" y2="' + e[1] + '"/><text x="' + a[0] + '" y="' + (a[1] + 4) + '" text-anchor="' + (Math.abs(a[0] - c) < 8 ? 'middle' : a[0] > c ? 'start' : 'end') + '">' + esc(tr(l)) + '</text>'; });
    spec.series.forEach(function (se, k) { var p = se.data.map(function (v, i) { return pt(i, v).map(function (q) { return q.toFixed(1); }).join(','); }).join(' '); s += '<polygon points="' + p + '" fill="' + col(se, k) + '" fill-opacity=".2" stroke="' + col(se, k) + '" stroke-width="2.5" stroke-linejoin="round"/>'; });
    return wrap(spec.title || 'radar', S, S, s, spec.series.length > 1 ? spec.series : null);
  }
  function donut(spec) {
    var S = 200, r = 74, cc = 2 * Math.PI * r, tot = spec.items.reduce(function (a, b) { return a + b.value; }, 0), off = 0, s = '<circle cx="100" cy="100" r="' + r + '" fill="none" stroke="var(--surface-3)" stroke-width="22"/>';
    spec.items.forEach(function (it, i) { var len = cc * it.value / tot; s += '<circle cx="100" cy="100" r="' + r + '" fill="none" stroke="' + (it.color || C[i % C.length]) + '" stroke-width="22" stroke-dasharray="' + (len - 2).toFixed(1) + ' ' + (cc - len + 2).toFixed(1) + '" stroke-dashoffset="' + (-off).toFixed(1) + '" transform="rotate(-90 100 100)"><title>' + esc(tr(it.label)) + ': ' + num(it.value) + '</title></circle>'; off += len; });
    s += '<text x="100" y="104" text-anchor="middle" style="font-size:30px;font-weight:800;fill:var(--text)">' + num(tot) + '</text><text x="100" y="124" text-anchor="middle">' + esc(tr(spec.center || '')) + '</text>';
    return wrap(spec.title || 'donut', S, S, s) + legend(spec.items.map(function (it, i) { return { name: it.label, color: it.color || C[i % C.length] }; }));
  }
  var R = { line: line, bars: bars, radar: radar, donut: donut };
  function render(m) { m.el.innerHTML = R[m.type](m.spec); }
  function mount(el, type, spec) {
    el = typeof el === 'string' ? document.querySelector(el) : el; if (!el) return;
    var m = { el: el, type: type, spec: spec }; mounted = mounted.filter(function (x) { return x.el !== el; }); mounted.push(m); render(m);
  }
  root.addEventListener('tkd:languagechange', function () { mounted.forEach(render); });
  root.TKDCharts = { mount: mount, line: line, bars: bars, radar: radar, donut: donut };
})(window);
