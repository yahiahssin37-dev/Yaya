# Fonts

**No font files are bundled in this package** — they could not be downloaded in the environment where the package was built, and shipping placeholder files would be misleading.

The design system uses two open-source (SIL OFL) families:

| Script | Family | Weights |
|---|---|---|
| Latin (French, numbers) | **Inter** | 400 · 500 · 600 · 700 · 800 |
| Arabic | **Cairo** | 400 · 500 · 600 · 700 · 800 |

## Option A — Google Fonts (default, already wired in `demo/index.html`)
```html
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Cairo:wght@400;500;600;700;800&family=Inter:wght@400;500;600;700;800&display=swap">
```
Works with the existing app's Helmet default CSP (`style-src https:` and `font-src https:` are allowed).

## Option B — self-host (offline / privacy)
1. Download Inter and Cairo (woff2) from <https://fonts.google.com> or <https://github.com/rsms/inter>.
2. Put the `.woff2` files in this folder and add `@font-face` rules to `styles/typography.css`.

## Fallbacks
If the fonts are unavailable the stacks fall back to `Segoe UI / system-ui / Roboto` (Latin) and `Segoe UI / Tahoma / Noto Sans Arabic` (Arabic), so the interface stays fully usable.
