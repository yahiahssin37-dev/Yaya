/* Demo-only sample data for the charts. In the real app, feed TKDCharts.mount() with your Evaluation records. */
window.TKD_DEMO = {
  charts: function () {
    var M = ['@m.jun', '@m.jul', '@m.aug', '@m.sep', '@m.oct', '@m.nov'], CATS = ['@cat.speed', '@cat.power', '@cat.endurance', '@cat.tactics', '@cat.focus'];
    TKDCharts.mount('#chart-perf', 'line', { title: 'Performance', labels: M, min: 60, max: 100, series: [{ name: '@ser.avg', data: [68, 72, 71, 76, 79, 84] }, { name: '@ser.target', data: [70, 72, 74, 76, 78, 80], color: 'var(--chart-2)' }], area: true });
    TKDCharts.mount('#chart-radar', 'radar', { title: 'Skills', labels: CATS, max: 100, series: [{ name: '@ser.current', data: [94, 88, 82, 90, 96] }, { name: '@ser.previous', data: [86, 80, 78, 82, 88], color: 'var(--chart-2)' }] });
    TKDCharts.mount('#chart-compare', 'bars', { title: 'Comparison', labels: ['Amira', 'Lina', 'Yassine', 'Mohamed', 'Omar'], max: 100, series: [{ name: '@ser.previous', data: [86, 87, 82, 80, 69], color: 'var(--chart-2)' }, { name: '@ser.current', data: [92, 88, 86, 78, 64] }] });
    TKDCharts.mount('#chart-trend', 'line', { title: 'Trend', labels: M, min: 50, max: 100, points: true, series: [{ name: '@cat.speed', data: [70, 74, 78, 80, 86, 92] }, { name: '@cat.power', data: [64, 66, 70, 74, 75, 80], color: 'var(--chart-2)' }, { name: '@cat.focus', data: [58, 62, 66, 70, 72, 78], color: 'var(--chart-3)' }], area: false });
    TKDCharts.mount('#chart-bars', 'bars', { title: 'Categories', labels: CATS, max: 100, series: [{ name: '@ser.team', data: [78, 74, 70, 76, 80], color: 'var(--chart-2)' }, { name: '@ser.best', data: [94, 88, 82, 90, 96] }] });
    TKDCharts.mount('#chart-donut', 'donut', { title: 'Belts', center: '@dash.athletes', items: [{ label: '@belt.white', value: 8 }, { label: '@belt.yellow', value: 9 }, { label: '@belt.green', value: 11 }, { label: '@belt.blue', value: 8 }, { label: '@belt.black', value: 6 }] });
    TKDCharts.mount('#chart-mini', 'bars', { title: 'Mini', height: 170, labels: ['@m.sep', '@m.oct', '@m.nov'], max: 100, series: [{ name: '@ser.avg', data: [76, 79, 84] }] });
  }
};
